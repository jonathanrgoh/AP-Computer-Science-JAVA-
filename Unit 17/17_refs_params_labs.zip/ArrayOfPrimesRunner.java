//(c) A+ Computer Science
//www.apluscompsci.com
//Name -

import static java.lang.System.*;
import java.lang.Math;
import java.util.Arrays;

public class ArrayOfPrimesRunner
{
	public static void main( String args[] )
	{
	   out.println("The 1st 5 primes starting from 2 are :: \n"+Arrays.toString(ArrayOfPrimes.getPrimeList(5)));   
	   
	   //add more test cases   
	   
	}
}